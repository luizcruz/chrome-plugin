
    const postID = document.body.outerHTML.split('<!-- PostID:')[1].split(' -->')[0];

    if (String(window.location.pathname).includes("galerias")) {
      chrome.storage.sync.get(["galleryPath"]).then((result) => {
        window.location.assign(result.galleryPath+'wp-admin/post.php?post='+postID+'&action=edit');
      });
  
    } else {
  
      chrome.storage.sync.get(["cmsPath"]).then((result) => {
        window.location.assign(result.cmsPath+'wp-admin/post.php?post='+postID+'&action=edit');
      });
  
    }
    
 