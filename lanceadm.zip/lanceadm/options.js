const saveButton = document.getElementById('saveButton');

function handleButtonClick(event) {

  let cmsPath = document.querySelector('input[name="cms-path"]').value
  let galleryPath = document.querySelector('input[name="cms-gallery-path"]').value


  chrome.storage.sync.set({ cmsPath: cmsPath }).then(() => {
    console.log("CMS Path configured");
  });

  chrome.storage.sync.set({ galleryPath: galleryPath }).then(() => {
    console.log("CMS Gallery Path configured");
  });



 
}


function constructOptions() {


  saveButton.addEventListener('click', handleButtonClick);


  chrome.storage.sync.get(["cmsPath"]).then((result) => {
    console.log("Value currently is " + result.cmsPath);
    document.querySelector('input[name="cms-path"]').value = result.cmsPath;
  });

  chrome.storage.sync.get(["galleryPath"]).then((result) => {
    console.log("Value currently is " + result.galleryPath);
    document.querySelector('input[name="cms-gallery-path"]').value = result.galleryPath;
  });


}

constructOptions();
